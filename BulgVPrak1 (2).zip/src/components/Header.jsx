const Header = () => {
    return (
        <header>
            <div className="container">
                <h1>Movie Library</h1>
            </div>
        </header>
    );
};

export default Header;
