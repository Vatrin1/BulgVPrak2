export function Preloader(){
    return(           
  <div class="progress">
        <div class="indeterminate"></div>
  </div>
    )
}