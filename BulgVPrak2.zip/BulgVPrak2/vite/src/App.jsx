import {Footer, Header, Shop} from "./layout"


export default function App() {
  return(
    <>
      <Header />
      <Shop />
      <Footer />
    </>
  );
}